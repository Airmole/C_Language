// �������Ķ���
#ifndef H_COACH
#define H_COACH

#include <string.h>
#include "Person.h"
#include "date.h"

class CCoach:public CPerson
{
public:
	CCoach()
	{
	}

	CCoach(char * name, CDate birthday, char * motherland, char * sex)
		:CPerson(name, birthday, motherland, sex)
	{		
	}

};
#endif
