// ��Ա�Ķ���

#ifndef H_PERSON
#define H_PERSON

#include <string.h>
#include <time.h>
#include "date.h"



class CPerson
{
	char name[10];
	CDate birthday;
	//int birthday;
	char motherland[20];
	char sex[3];

public:
	CPerson()
	{
	}

	CPerson(char * name, CDate b, char * motherland, char * sex):birthday(b)
	{
		strcpy(this->name, name);
		strcpy(this->motherland, motherland);
		strcpy(this->sex, sex);
	}

	CPerson(CPerson &p)
	{
		strcpy(this->name, p.name);
		birthday = p.birthday;
		strcpy(this->motherland, p.motherland);
		strcpy(this->sex, p.sex);
	}
	void setName(char * name)
	{
		strcpy(name, name);
	}
	char * getName()
	{
		return name;
	}

};
#endif