#ifndef H_PLAYER
#define H_PLAYER

#include <string.h>
#include "Person.h"
#include "date.h"

class CPlayer:public CPerson
{
	CDate servingOfYears;
	char position[10];

	bool captionFlag;//��ʶ�Ƿ�Ϊ�ӳ�
	int numberOfCoat; //����������
public:
	CPlayer()
	{
		captionFlag = false;
	}
	CPlayer(char * name, CDate birthday, char * motherland, char * sex,
		CDate servingYears, char * position, int numberOfCoat, bool captionFlag=false)
		:CPerson(name, birthday, motherland, sex),servingOfYears(servingYears)
	{

		this->captionFlag = captionFlag;
	}
	CPlayer(CPlayer &p):CPerson(p)
	{
		this->captionFlag = p.captionFlag;
		this->numberOfCoat = p.numberOfCoat;
	}
	bool isCaption()
	{
		if(captionFlag)
			return true;
	}
	void setNumberOfCoat(int number)
	{
		numberOfCoat = number;
	}
	int getNumberOfCoat()
	{
		return numberOfCoat;
	}
	void setCaption()
	{
		captionFlag = true;
	}
	void offSetCaption()
	{
		captionFlag = false;
	}

};
#endif