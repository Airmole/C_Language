#ifndef H_DATE
#define H_DATE
class CDate
{
	int year;
	int month;
	int day;
public:
	CDate()
	{
	}
	CDate(int year, int month, int day)
	{
		this->year = year;
		this->month = month;
		this->day = day;
	}
	CDate(CDate & d)
	{
		year = d.year;
		month = d.month;
		day = d.day;
	}
	void setDate(int year, int month, int day)
	{
		this->year = year;
		this->month = month;
		this->day = day;
	}

	void setDate(CDate & d)
	{
		year = d.year;
		month = d.month;
		day = d.day;
	}

};

class CTime
{
	int hour;
	int minute;
	int second;
public:
	CTime()
	{
	}
	CTime(int hour, int minute, int second)
	{
		this->hour = hour;
		this->minute = minute;
		this->second = second;
	}
	void setTime(int hour, int minute, int second)
	{
		this->hour = hour;
		this->minute = minute;
		this->second = second;
	}

	void setTime(CTime & t)
	{
		hour = t.hour;
		minute = t.minute;
		second = t.second;
	}
};

#endif
